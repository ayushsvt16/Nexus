package com.nexus.nexusproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NexusprojectApplication {
    public static void main(String[] args) {
        SpringApplication.run(NexusprojectApplication.class, args);
    }
}